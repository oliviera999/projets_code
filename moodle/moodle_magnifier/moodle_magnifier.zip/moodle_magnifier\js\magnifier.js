/**
 * local_magnifier — Barre de progression au scroll et back-to-top.
 * Sélecteurs limités aux éléments du plugin (pas de conflit avec le thème).
 * Utilise document.scrollingElement pour le scroll et réessaie si les éléments sont injectés tard (footer Moodle).
 */
(function() {
  "use strict";

  var progressBar = null;
  var backToTop = null;
  var ticking = false;

  function getScrollValues() {
    var el = document.scrollingElement || document.documentElement;
    var scrollTop = el.scrollTop;
    var scrollHeight = el.scrollHeight;
    var clientHeight = el.clientHeight;
    var maxScroll = Math.max(0, scrollHeight - clientHeight);
    return { scrollTop: scrollTop, maxScroll: maxScroll };
  }

  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(function() {
        var v = getScrollValues();
        var scrollY = v.scrollTop;
        var docHeight = v.maxScroll;
        if (progressBar) {
          progressBar.style.width = (docHeight > 0 ? (scrollY / docHeight) * 100 : 0) + "%";
        }
        if (backToTop) {
          backToTop.classList.toggle("active", scrollY > 100);
        }
        ticking = false;
      });
      ticking = true;
    }
  }

  function attachListeners() {
    window.addEventListener("load", onScroll);
    window.addEventListener("scroll", onScroll, { passive: true });
    if (backToTop) {
      backToTop.addEventListener("click", function(e) {
        e.preventDefault();
        var el = document.scrollingElement || document.documentElement;
        if (el && el.scrollTo) {
          el.scrollTo({ top: 0, behavior: "smooth" });
        } else {
          window.scrollTo({ top: 0, behavior: "smooth" });
        }
      });
    }
  }

  function run() {
    progressBar = document.getElementById("local_magnifier-scroll-progress");
    backToTop = document.getElementById("local_magnifier-back-to-top");
    if (!progressBar && !backToTop) {
      return false;
    }
    attachListeners();
    onScroll();
    return true;
  }

  function initAOS() {
    if (typeof AOS !== "undefined") {
      AOS.init({
        duration: 600,
        easing: "ease-out-cubic",
        offset: 80,
        once: true,
        disable: false
      });
    }
  }

  function init() {
    run();
    initAOS();
    window.addEventListener("aos-loaded", initAOS);
    if (!progressBar && !backToTop) {
      window.addEventListener("load", function() {
        if (run()) {
          onScroll();
        } else {
          setTimeout(function() {
            run();
            onScroll();
          }, 300);
        }
        initAOS();
      });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
