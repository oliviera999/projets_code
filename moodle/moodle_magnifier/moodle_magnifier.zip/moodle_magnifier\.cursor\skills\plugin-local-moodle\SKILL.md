---
name: plugin-local-moodle
description: Créer ou modifier un plugin local Moodle (structure, version.php, lang, lib.php, Hooks). Utiliser quand on ajoute ou modifie du code dans local_magnifier ou tout plugin local Moodle.
---

# Plugin local Moodle — Création et modification

## Quand l'utiliser

- Création ou modification d'un plugin local Moodle (ex. `local_magnifier`).
- Ajout de callbacks, Hooks, ou de fichiers obligatoires (version.php, lang, lib.php).
- Injection de HTML/JS/CSS dans les pages Moodle.

## Structure minimale

- **version.php** : `$plugin->component = 'local_magnifier'`, `$plugin->version`, `$plugin->requires` (ex. 2024110400 pour Moodle 5.0), `$plugin->maturity`.
- **lang/en/local_magnifier.php** : au minimum `$string['pluginname'] = 'Magnifier';`.
- **lib.php** : garder minimal ; uniquement les callbacks requis qui n'ont pas d'équivalent Hook (ex. `local_magnifier_extend_navigation`). Pas de logique métier.
- **classes/** : toute la logique dans des classes autoloadées (namespace `local_magnifier\`).

## Injection de contenu (JS/CSS/HTML)

- **Préférence** : Hooks (Moodle 4.3+) — ex. `core\hook\output\before_standard_footer_html` déclaré dans `db/hooks.php`, callback qui appelle `$hook->add_html(...)` et/ou enregistre des CSS/JS via `$PAGE->requires`.
- **Sinon** : callback legacy dans lib.php (ex. `local_magnifier_before_footer()`) qui retourne du HTML ou enregistre des assets.
- Servir les assets depuis le plugin : `$PAGE->requires->css('/local/magnifier/styles/xxx.css')`, `$PAGE->requires->js('/local/magnifier/amd/xxx.js')` (ou équivalent).

## Checklist

1. Vérifier que `version.php` est à jour (version, requires).
2. Ne pas mettre de logique lourde dans `lib.php`.
3. Après modification de `db/hooks.php` ou des callbacks : purger les caches Moodle (Administration > Développement > Purge des caches) ou incrémenter la version du plugin.
4. Tester l'installation / mise à jour du plugin et l'affichage des effets sur une page (sans modifier Moodle_prod).

## Références

- [Local plugins — Moodle Developer Resources](https://moodledev.io/docs/5.0/apis/plugintypes/local)
- [Hooks API](https://moodledev.io/docs/apis/core/hooks)
- Règles du projet : `moodle-magnifier-plugin-structure.mdc`, `moodle-magnifier-conventions.mdc`
