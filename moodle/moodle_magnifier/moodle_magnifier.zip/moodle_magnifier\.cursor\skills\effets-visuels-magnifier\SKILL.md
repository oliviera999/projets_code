---
name: effets-visuels-magnifier
description: Ajouter ou reproduire des effets visuels du plugin Magnifier en s'inspirant de index.olution.info et moodle/index_olution. Utiliser quand on implémente AOS, barre de scroll, back-to-top, ou tout effet visuel cohérent avec la vitrine Olution.
---

# Effets visuels Magnifier — Référence index_olution

## Quand l'utiliser

- Ajout ou reproduction d'effets visuels dans le plugin local_magnifier (barre de progression au scroll, back-to-top, animations au scroll type AOS).
- Harmonisation du rendu Moodle avec la vitrine index.olution.info.

## Référence à consulter

- **Page** : [index.olution.info](https://index.olution.info)
- **Fichiers du projet** :
  - `moodle/index_olution/assets/js/main.js` : AOS.init, barre de progression (scroll), navigation active, back-to-top, liens externes _blank.
  - `moodle/index_olution/assets/css/style.css` : variables CSS (`:root`), `.scroll-progress`, transitions, ombres.

## Principes d'adaptation pour Moodle

1. **Injection** : Ne pas modifier les thèmes. Injecter le HTML/JS/CSS via le plugin (Hooks ou callbacks before_footer). Servir les assets depuis le plugin (`/local/magnifier/...`).
2. **Sélecteurs** : Préfixer les classes/IDs pour éviter les conflits avec Boost Union (ex. `.local_magnifier-scroll-progress`, `#local_magnifier-back-to-top`).
3. **Compatibilité** : Le code doit fonctionner avec Boost et tous les thèmes enfants Boost Union (n3, bleu, farmflow, etc.) sans surcharge de thème.

## Effets principaux à reproduire (référence index_olution)

- **Barre de progression au scroll** : div fixe en haut, largeur en % selon `scrollY / (scrollHeight - innerHeight)`.
- **Back-to-top** : lien ou bouton fixe en bas à droite, visible après un certain scroll (ex. > 100px), smooth scroll vers le haut.
- **AOS (Animate On Scroll)** : optionnel ; si utilisé, charger la lib depuis CDN ou copier une version minimale, initialiser avec `once: true` pour éviter les conflits avec le DOM Moodle.

## Checklist

1. Vérifier que les sélecteurs sont préfixés (pas de conflit avec le thème).
2. S'assurer que les scripts ne ciblent pas des IDs/classes du noyau Moodle ou du thème.
3. Tester sur au moins un thème enfant Boost Union (ex. n3).
