# build-archive.ps1 — Crée une archive du plugin local_magnifier, incrémente la version, commit et pousse vers GitHub.
# À lancer depuis la racine du dossier moodle_magnifier (ou depuis le dépôt avec -PluginPath).
# L'archive est créée à la racine de moodle_magnifier : local_magnifier-<release>.zip

param(
    [string]$PluginPath = $PSScriptRoot,
    [ValidateSet("patch", "minor", "major")]
    [string]$Bump = "patch",
    [switch]$NoVersion,
    [switch]$NoPush
)

$ErrorActionPreference = "Stop"
$scriptName = "build-archive.ps1"

# Répertoire de travail = racine du plugin
$root = $PluginPath
if (-not (Test-Path -LiteralPath (Join-Path $root "version.php"))) {
    Write-Error "version.php introuvable dans '$root'. Lancez le script depuis la racine de moodle_magnifier ou indiquez -PluginPath."
}

$versionPhpPath = Join-Path $root "version.php"
$versionPhp = Get-Content -Raw -Path $versionPhpPath

# Extraire version et release depuis version.php
if ($versionPhp -match "\`$plugin->version\s*=\s*(\d+);") {
    $pluginVersion = [long]$Matches[1]
} else {
    Write-Error "Impossible d'extraire plugin->version depuis version.php."
}
if ($versionPhp -match "\`$plugin->release\s*=\s*'([^']+)'") {
    $release = $Matches[1]
} else {
    Write-Error "Impossible d'extraire plugin->release depuis version.php."
}

# Incrémenter la version (sauf si -NoVersion)
if (-not $NoVersion) {
    # Bump semver (release)
    $parts = $release -split '\.'
    $major = [int]$parts[0]
    $minor = [int]$parts[1]
    $patch = [int]$parts[2]
    switch ($Bump) {
        "major" { $major++; $minor = 0; $patch = 0 }
        "minor" { $minor++; $patch = 0 }
        "patch" { $patch++ }
    }
    $release = "$major.$minor.$patch"
    # Incrémenter $plugin->version (YYYYMMDDNN)
    $pluginVersion++

    $versionPhp = $versionPhp -replace "(\`$plugin->version\s*=\s*)\d+;", "`${1}$pluginVersion;"
    $versionPhp = $versionPhp -replace "(\`$plugin->release\s*=\s*)'[^']+';", "`${1}'$release';"
    Set-Content -Path $versionPhpPath -Value $versionPhp -NoNewline
    Write-Host "Version mise à jour : release=$release, version=$pluginVersion"
}

# Même nom que l'archive de référence qui s'installe sans demander le type de plugin
$archiveName = "moodle_magnifier.zip"
$archivePath = Join-Path $root $archiveName

# Exclure uniquement ce qui n'a pas sa place sur un serveur Moodle (.git, archives, node_modules)
$tempBase = Join-Path ([System.IO.Path]::GetTempPath()) "local_magnifier_build_$([Guid]::NewGuid().ToString('N').Substring(0,8))"
$pluginRootDir = Join-Path $tempBase "moodle_magnifier"
New-Item -ItemType Directory -Path $pluginRootDir -Force | Out-Null

try {
    # Copier tout le contenu source (comme l'archive de référence : racine moodle_magnifier/)
    Get-ChildItem -Path $root -Force -Recurse | Where-Object {
        $rel = $_.FullName.Substring($root.Length).TrimStart("\", "/")
        if ([string]::IsNullOrWhiteSpace($rel)) { return $false }
        $top = ($rel -split [regex]::Escape([IO.Path]::DirectorySeparatorChar))[0]
        if ($top -eq ".git" -or $top -eq "node_modules") { return $false }
        if ($_.Extension -eq ".zip") { return $false }
        return $true
    } | ForEach-Object {
        $relativePath = $_.FullName.Substring($root.Length).TrimStart("\", "/")
        $destPath = Join-Path $pluginRootDir $relativePath
        if ($_.PSIsContainer) {
            New-Item -ItemType Directory -Path $destPath -Force | Out-Null
        } else {
            $destDir = [System.IO.Path]::GetDirectoryName($destPath)
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            Copy-Item -LiteralPath $_.FullName -Destination $destPath -Force
        }
    }

    # Créer l'archive : racine "moodle_magnifier" (structure identique au ZIP de référence qui s'installe sans demander le type)
    if (Test-Path $archivePath) { Remove-Item $archivePath -Force }
    Compress-Archive -Path $pluginRootDir -DestinationPath $archivePath -CompressionLevel Optimal

    Write-Host "Archive créée : $archivePath"
    Write-Host "Version (release) : $release"
    Write-Host "Déploiement Moodle : Administration du site > Plugins > Installer des plugins > Téléverser $archiveName (s’installe sans demander le type de plugin)."
} finally {
    if (Test-Path $tempBase) { Remove-Item -Recurse -Force $tempBase }
}

# Git : commit et push (depuis la racine du dépôt)
$gitRoot = & git -C $root rev-parse --show-toplevel 2>$null
if (-not $gitRoot) {
    Write-Warning "Pas un dépôt git (ou git absent). Commit et push ignorés."
} else {
    $relPathVersion = $root.Substring($gitRoot.Length).TrimStart("\", "/").Replace("\", "/")
    $relPathZip = "$relPathVersion/$archiveName"
    & git -C $gitRoot add "$relPathVersion/version.php" $relPathZip 2>$null
    $status = & git -C $gitRoot status --porcelain "$relPathVersion/version.php" "$relPathZip" 2>$null
    if ($status) {
        & git -C $gitRoot commit -m "Release local_magnifier $release"
        if ($LASTEXITCODE -ne 0) { Write-Error "Erreur git commit." }
        if (-not $NoPush) {
            & git -C $gitRoot push
            if ($LASTEXITCODE -ne 0) { Write-Error "Erreur git push." }
            Write-Host "Poussé vers GitHub."
        } else {
            Write-Host "Commit créé. Relancez sans -NoPush pour pousser vers GitHub."
        }
    } else {
        Write-Host "Aucun changement à committer (version déjà à jour et archive à jour)."
    }
}
