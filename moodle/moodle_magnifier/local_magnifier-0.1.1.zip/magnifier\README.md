# local_magnifier — Plugin Moodle Magnifier

Plugin local Moodle 5 qui **magnifie** la plateforme avec des effets visuels (barre de progression au scroll, back-to-top, etc.), compatibles avec tout thème (Boost, Boost Union et thèmes enfants).

## Référence visuelle

- Page : [index.olution.info](https://index.olution.info)
- Fichiers de référence dans le projet : `moodle/index_olution/assets/js/main.js`, `moodle/index_olution/assets/css/style.css`

## Déploiement

- **Développement** : le code source du plugin est dans ce dossier (`moodle/moodle_magnifier/`).
- **Production** : copier le contenu de ce dossier vers `Moodle_prod/local/magnifier/`. Ne pas modifier les autres fichiers de Moodle_prod.

### Archive pour installation manuelle

À chaque mise à jour de version, créer une archive prête pour le déploiement :

```powershell
# Depuis la racine de moodle_magnifier
.\build-archive.ps1
```

L’archive `local_magnifier-<release>.zip` (ex. `local_magnifier-0.1.0.zip`) est créée à la racine du dossier. Elle contient le dossier `magnifier` attendu par Moodle. Pour installer : **Administration du site > Plugins > Installer des plugins**, téléverser le ZIP (Moodle l’extrait dans `local/magnifier/`).

## Structure

- `version.php`, `lib.php`, `lang/`, `db/hooks.php`, `classes/` : structure standard d’un plugin local Moodle.
- Les effets sont injectés via le Hook `before_standard_footer_html_generation` (Moodle 4.3+).

## Règles et skills

Les règles Cursor et les skills du projet sont dans `.cursor/rules/` et `.cursor/skills/`.
