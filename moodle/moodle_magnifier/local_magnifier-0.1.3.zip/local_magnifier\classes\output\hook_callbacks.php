<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_magnifier\output;

use core\hook\output\before_standard_footer_html_generation;
use core\hook\output\before_standard_head_html_generation;

/**
 * Hook callbacks for output hooks.
 *
 * @package    local_magnifier
 * @copyright  2025
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class hook_callbacks {

    /**
     * Add Magnifier CSS and JS in the page head.
     *
     * @param before_standard_head_html_generation $hook
     */
    public static function before_standard_head_html(before_standard_head_html_generation $hook): void {
        global $CFG;
        if (during_initial_install() || !get_config('local_magnifier', 'version')) {
            return;
        }
        $html = '';
        $aos_enabled = get_config('local_magnifier', 'aos_enabled');
        if ($aos_enabled === false) {
            $aos_enabled = 1;
        }
        if ($aos_enabled) {
            $html .= '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">';
            $html .= '<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js" defer></script>';
        }
        $base = $CFG->wwwroot . '/local/magnifier/';
        $version = get_config('local_magnifier', 'version');
        $html .= '<link rel="stylesheet" href="' . $base . 'styles/magnifier.css?v=' . $version . '">';
        $html .= '<script src="' . $base . 'js/magnifier.js?v=' . $version . '" defer></script>';
        $hook->add_html($html);
    }

    /**
     * Add Magnifier HTML before the standard footer (scroll progress, back-to-top, etc.).
     *
     * @param before_standard_footer_html_generation $hook
     */
    public static function before_standard_footer_html(before_standard_footer_html_generation $hook): void {
        if (during_initial_install() || !get_config('local_magnifier', 'version')) {
            return;
        }
        $html = '<div id="local_magnifier-scroll-progress" class="local_magnifier-scroll-progress" aria-hidden="true"></div>';
        $html .= '<a href="#" id="local_magnifier-back-to-top" class="local_magnifier-back-to-top" aria-label="Back to top">↑</a>';
        $hook->add_html($html);
    }
}
