# local_magnifier — Plugin Moodle Magnifier

Plugin local Moodle 5 qui **magnifie** la plateforme avec des effets visuels (barre de progression au scroll, back-to-top, etc.), compatibles avec tout thème (Boost, Boost Union et thèmes enfants).

## Référence visuelle

- Page : [index.olution.info](https://index.olution.info)
- Fichiers de référence dans le projet : `moodle/index_olution/assets/js/main.js`, `moodle/index_olution/assets/css/style.css`

## Déploiement

- **Développement** : le code source du plugin est dans ce dossier (`moodle/moodle_magnifier/`).
- **Production** : copier le contenu de ce dossier vers `Moodle_prod/local/magnifier/`. Ne pas modifier les autres fichiers de Moodle_prod.

### Archive pour installation manuelle

Le script `build-archive.ps1` crée l’archive, incrémente la version du plugin, crée un commit et pousse vers GitHub :

```powershell
# Depuis la racine de moodle_magnifier
.\build-archive.ps1
```

Comportement par défaut :
1. Incrémente la version dans `version.php` (release en patch : 0.1.0 → 0.1.1, et `$plugin->version`).
2. Crée l’archive `local_magnifier-<release>.zip` à la racine du dossier (contenu : dossier `magnifier` pour Moodle).
3. Commit des fichiers `version.php` et du ZIP avec le message `Release local_magnifier <release>`.
4. Push vers le dépôt distant (origin).

Options utiles :
- `-NoVersion` : ne pas incrémenter la version (créer seulement l’archive et le commit).
- `-NoPush` : faire le commit mais ne pas pousser (ex. pour relancer le push plus tard).
- `-Bump minor` ou `-Bump major` : incrémenter minor (0.1.0 → 0.2.0) ou major (0.1.0 → 1.0.0) au lieu du patch.

Exemple : créer l’archive et committer sans pousser : `.\build-archive.ps1 -NoPush`

Pour installer sur Moodle : **Administration du site > Plugins > Installer des plugins**, téléverser le ZIP (Moodle l’extrait dans `local/magnifier/`).

## Structure

- `version.php`, `lib.php`, `lang/`, `db/hooks.php`, `classes/` : structure standard d’un plugin local Moodle.
- Les effets sont injectés via le Hook `before_standard_footer_html_generation` (Moodle 4.3+).

## Règles et skills

Les règles Cursor et les skills du projet sont dans `.cursor/rules/` et `.cursor/skills/`.
